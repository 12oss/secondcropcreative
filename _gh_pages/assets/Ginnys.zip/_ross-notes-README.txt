A few things I wanted to note about my design:

- I wanted to lead the customer down the email visually by using an ‘overlapping’ layout to tie all the elements together

- I added product names and price callouts to tie it back to catalog motif. I also added the secondary message within the smartwatch area to give a little more content to the email message. (Honestly I figured the two big ticket items in the email should have supporting copy to help sell it)

- I did perform just minor image adjusts to all images (i.e. lighten, darken, sharpen, contrast, masking, cloning and clipping paths) - I wasn’t sure what the latitude on that is, but part of my side hustle is photo retouching/manipulations/photoshop requests. (https://fixmyphotobro.com) 

- choice of color was just pulling it out of the feature image. I wanted to keep colors limited.

- Same with fonts - I wanted to stick to a limited selection, but emphasis the main message and cta so the rest of the email could sit nicely as a supporting role (i.e. introducing visual hierarchy into the email)

- And finally, my Photoshop file is arranged in its manner (seemingly upside down based on the content in the email) to achieve that overlapping effect. Had I not gone that way with the design, my layer structure would have matched the email layout (i.e. top to bottom)

Let me know if you have any questions about the design, my PS file or how I managed to pull anything off!
